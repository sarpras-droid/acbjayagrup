ACB JAYA GRUP — Android WebView v1.1

Fitur:
- Ikon aplikasi sederhana bertema ACB.
- Header ACB Jaya Grup.
- Tombol Beranda, Katalog, dan Cari.
- Menu katalog dengan beberapa kategori contoh.
- Tombol WhatsApp. Masukkan nomor WhatsApp bisnis yang benar saat aplikasi dijalankan.
- Nomor WhatsApp tersimpan lokal di perangkat.
- JavaScript, DOM storage, indikator muat halaman, dan tombol kembali Android.

PENTING:
1. Kategori katalog menggunakan URL label contoh Blogger: Mesin, Mesin Makanan, dan Peralatan. Sesuaikan label dengan label yang benar di website.
2. Nomor WhatsApp tidak diketahui saat proyek dibuat, jadi aplikasi meminta pengguna memasukkan nomor resmi bisnis.
3. Ini proyek sumber, bukan APK yang sudah dikompilasi.

Cara membuat APK:
1. Instal Android Studio di komputer.
2. Ekstrak ZIP dan buka folder proyek di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

Pastikan Anda memiliki izin untuk menggunakan nama, logo, dan konten bisnis terkait.
