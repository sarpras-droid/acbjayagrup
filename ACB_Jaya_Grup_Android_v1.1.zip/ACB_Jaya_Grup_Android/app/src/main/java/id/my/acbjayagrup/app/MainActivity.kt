package id.my.acbjayagrup.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private val homeUrl = "https://www.acbjayagrup.my.id/?m=1"
    private val navy = Color.rgb(28, 55, 85)
    private val gold = Color.rgb(244, 185, 66)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(navy)
        }
        val logo = TextView(this).apply {
            text = "ACB"
            textSize = 18f
            setTextColor(navy)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(gold)
            setPadding(dp(9), dp(8), dp(9), dp(8))
        }
        val brand = TextView(this).apply {
            text = "ACB JAYA GRUP\nMesin & Peralatan Usaha"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), 0, 0, 0)
        }
        header.addView(logo)
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val waHeader = Button(this).apply {
            text = "WhatsApp"
            textSize = 11f
            setTextColor(navy)
            setOnClickListener { openWhatsAppDialog() }
        }
        header.addView(waHeader)
        root.addView(header)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(5), dp(8), dp(5))
            setBackgroundColor(Color.rgb(242, 245, 248))
        }
        nav.addView(navButton("Beranda") { webView.loadUrl(homeUrl) },
            LinearLayout.LayoutParams(0, dp(44), 1f))
        nav.addView(navButton("Katalog") { showCatalogMenu() },
            LinearLayout.LayoutParams(0, dp(44), 1f))
        nav.addView(navButton("Cari") { showSearchDialog() },
            LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(nav)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(gold)
        }
        root.addView(progressBar, LinearLayout.LayoutParams(-1, dp(3)))

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.useWideViewPort = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: ""
                if (scheme == "http" || scheme == "https") return false
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Tautan tidak dapat dibuka", Toast.LENGTH_SHORT).show()
                    true
                }
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl(homeUrl)
    }

    private fun navButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setTextColor(navy)
            setOnClickListener { action() }
        }

    private fun showCatalogMenu() {
        val choices = arrayOf(
            "Semua katalog",
            "Mesin usaha",
            "Mesin makanan",
            "Peralatan produksi"
        )
        AlertDialog.Builder(this)
            .setTitle("Navigasi katalog")
            .setItems(choices) { _, which ->
                when (which) {
                    0 -> webView.loadUrl(homeUrl)
                    1 -> webView.loadUrl("https://www.acbjayagrup.my.id/search/label/Mesin?m=1")
                    2 -> webView.loadUrl("https://www.acbjayagrup.my.id/search/label/Mesin%20Makanan?m=1")
                    3 -> webView.loadUrl("https://www.acbjayagrup.my.id/search/label/Peralatan?m=1")
                }
            }.show()
    }

    private fun showSearchDialog() {
        val input = EditText(this).apply {
            hint = "Contoh: mesin parut kelapa"
            setSingleLine(true)
            setPadding(dp(18), dp(12), dp(18), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle("Cari produk di ACB Jaya Grup")
            .setView(input)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Cari") { _, _ ->
                val query = input.text.toString().trim()
                if (query.isNotEmpty()) {
                    val encoded = Uri.encode(query)
                    webView.loadUrl("https://www.acbjayagrup.my.id/search?q=$encoded")
                }
            }.show()
    }

    private fun openWhatsAppDialog() {
        val prefs = getSharedPreferences("acb_settings", MODE_PRIVATE)
        val saved = prefs.getString("whatsapp_number", "") ?: ""
        val input = EditText(this).apply {
            hint = "Contoh: 6281234567890"
            setSingleLine(true)
            setText(saved)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        AlertDialog.Builder(this)
            .setTitle("WhatsApp ACB Jaya Grup")
            .setMessage("Masukkan nomor WhatsApp bisnis dengan kode negara, tanpa tanda + atau spasi. Nomor disimpan di perangkat ini.")
            .setView(input)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Buka WhatsApp") { _, _ ->
                var number = input.text.toString().filter { it.isDigit() }
                if (number.startsWith("0")) number = "62" + number.drop(1)
                if (number.length < 10) {
                    Toast.makeText(this, "Nomor belum valid. Periksa kembali.", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putString("whatsapp_number", number).apply()
                    val url = "https://wa.me/$number?text=" + Uri.encode("Halo ACB Jaya Grup, saya ingin bertanya tentang produk.")
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            }.show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
