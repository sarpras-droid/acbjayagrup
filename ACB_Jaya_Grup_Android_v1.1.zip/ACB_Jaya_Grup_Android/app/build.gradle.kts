plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.my.acbjayagrup.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.my.acbjayagrup.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}
